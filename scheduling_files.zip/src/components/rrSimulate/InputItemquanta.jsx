import React from "react";

const InputItemquanta = ({ quantInput, onDeleteq }) => {
  return <>{"Quantum time entered successfully"}</>;
};

export default InputItemquanta;
